//Autores: Marcela Lima e Ricardo Jordan

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
#include <string.h>

// Tamanho do tabuleiro
#define TAM 5

// Pontuação dos barcos
#define P_AVIOES 20
#define N_TANQUE 15
#define CONTRATORP 10
#define SUBMARINO 5

// Códigos dos barcos
#define AGUA 0
#define SUB 1
#define CONTRA 2
#define TANQUE 3
#define AVIAO 4

// Quantidade de cada barco
#define Q_SUB 4
#define Q_CONTRA 3
#define Q_TANQUE 2
#define Q_AVIAO 1

void limparTela() {
    system("cls");
}

void mostrarRegras() {
    printf("         ~~~~~~   __/___     ~~~~~~\n");
    printf("  ~~~~~     _____/_______|           ~~~~~~\n");
    printf("          \\              \\___\n");
    printf("  ~~~~~~~  \\______________/   ~~~~~~~\n");
    printf("     ~~~~~~  ~~~~~~~~       ~~~~~~\n");

    
    printf("%c", 201); 
    for (int i = 0; i < 87; i++) {
        printf("%c", 205); 
    }
    printf("%c\n", 187); 


    printf("%c=======================================================================================%c\n", 186, 186);
    printf("%c                               JOGO BATALHA NAVAL                                     %c\n", 186, 186);
    printf("%c=======================================================================================%c\n", 186, 186);
    printf("%c>> Regras Gerais:                                                                     %c\n", 186, 186);
    printf("%c- Dois jogadores participam.                                                          %c\n", 186, 186);
    printf("%c- Cada jogador possui um tabuleiro 5x5 com seus barcos posicionados aleatoriamente.  %c\n", 186, 186);
    printf("%c- Cada jogador possui os seguintes barcos:                                            %c\n", 186, 186);
    printf("%c  * 1 Porta-Aviões (Vale 20 pontos)                                                   %c\n", 186, 186);
    printf("%c  * 2 Navios-Tanques (Cada um vale 15 pontos)                                         %c\n", 186, 186);
    printf("%c  * 3 Contratorpedeiros (Cada um vale 10 pontos)                                      %c\n", 186, 186);
    printf("%c  * 4 Submarinos (Cada um vale 5 pontos)                                              %c\n", 186, 186);
    printf("%c>> Como Jogar:                                                                        %c\n", 186, 186);
    printf("%c- Os jogadores jogam alternadamente.                                                  %c\n", 186, 186);
    printf("%c- Se o jogador acertar um barco, joga novamente.                                     %c\n", 186, 186);
    printf("%c- Se errar (acertar água), passa a vez ao outro jogador.                             %c\n", 186, 186);
    printf("%c- O jogo termina quando:                                                              %c\n", 186, 186);
    printf("%c  * Um jogador destrói todos os navios do adversário; ou                             %c\n", 186, 186);
    printf("%c  * O tempo de 10 minutos acabar: vence quem tiver mais pontos.                       %c\n", 186, 186);
    printf("%c>> Importante:                                                                        %c\n", 186, 186);
    printf("%c- Os navios são posicionados aleatoriamente.                                          %c\n", 186, 186);
    printf("%c- Insira coordenadas de 0 a 4 (linha e coluna).                                       %c\n", 186, 186);
    printf("%cPressione ENTER para começar o jogo...                                               %c\n", 186, 186);

    
    printf("%c", 200); 
    for (int i = 0; i < 87; i++) {
        printf("%c", 205);
    }
    printf("%c\n", 188); 

    getchar();
    limparTela();
}


void inicializarTabuleiro(int tabuleiro[TAM][TAM]) {
    for (int i = 0; i < TAM; i++)
        for (int j = 0; j < TAM; j++)
            tabuleiro[i][j] = AGUA;
}

void posicionarBarcos(int tabuleiro[TAM][TAM], int tipo, int quantidade) {
    int colocados = 0;
    while (colocados < quantidade) {
        int x = rand() % TAM;
        int y = rand() % TAM;
        if (tabuleiro[x][y] == AGUA) {
            tabuleiro[x][y] = tipo;
            colocados++;
        }
    }
}

void mostrarTabuleiro(int tabuleiro[TAM][TAM], int ocultar) {
    printf("   0 1 2 3 4\n");
    for (int i = 0; i < TAM; i++) {
        printf("%d  ", i);
        for (int j = 0; j < TAM; j++) {
            if (ocultar && (tabuleiro[i][j] >= SUB && tabuleiro[i][j] <= AVIAO))
                printf(". ");
            else if (tabuleiro[i][j] == -1)
                printf("~ ");
            else if (tabuleiro[i][j] == -2)
                printf("X ");
            else
                printf(". ");
        }
        printf("\n");
    }
}

int pontuacao(int tipo) {
    switch (tipo) {
        case SUB: return SUBMARINO;
        case CONTRA: return CONTRATORP;
        case TANQUE: return N_TANQUE;
        case AVIAO: return P_AVIOES;
        default: return 0;
    }
}

const char* nomeBarco(int tipo) {
    switch (tipo) {
        case SUB: return "Submarino";
        case CONTRA: return "Contratorpedeiro";
        case TANQUE: return "Navio-Tanque";
        case AVIAO: return "Porta-Aviões";
        default: return "Desconhecido";
    }
}

int disparar(int tabuleiro[TAM][TAM], int x, int y, int *pontuacaoJogador) {
    if (x < 0 || x >= TAM || y < 0 || y >= TAM) {
        printf("Coordenadas inválidas!\n");
        return 0;
    }

    if (tabuleiro[x][y] >= SUB && tabuleiro[x][y] <= AVIAO) {
        int tipo = tabuleiro[x][y];
        int pontos = pontuacao(tipo);
        *pontuacaoJogador += pontos;
        tabuleiro[x][y] = -2;
        printf("Acertou um %s! Ganhou %d pontos.\n", nomeBarco(tipo), pontos);
        return 1;
    } else if (tabuleiro[x][y] == AGUA) {
        tabuleiro[x][y] = -1;
        printf("Errou! Acertou a água...\n");
    } else {
        printf("Essa posição já foi jogada. Tente novamente.\n");
    }

    return 0;
}

int todosNaviosDestruidos(int tabuleiro[TAM][TAM]) {
    for (int i = 0; i < TAM; i++)
        for (int j = 0; j < TAM; j++)
            if (tabuleiro[i][j] >= SUB && tabuleiro[i][j] <= AVIAO)
                return 0;
    return 1;
}

int lerCoordenadas(int *linha, int *coluna) {
    char entrada[100];
    if (!fgets(entrada, sizeof(entrada), stdin)) return 0;
    if (sscanf(entrada, "%d %d", linha, coluna) != 2) {
        printf("Entrada inválida! Use apenas dois números (linha e coluna) de 0 a 4.\n");
        return 0;
    }
    if (*linha < 0 || *linha >= TAM || *coluna < 0 || *coluna >= TAM) {
        printf("Coordenadas fora do intervalo (0 a 4).\n");
        return 0;
    }
    return 1;
}

int main() {
    setlocale(LC_ALL, "Portuguese");
    srand(time(NULL));

    int tabuleiro1[TAM][TAM], tabuleiro2[TAM][TAM];
    int pontos1 = 0, pontos2 = 0;
    int jogador = 1;
    int x, y;

    mostrarRegras();

    inicializarTabuleiro(tabuleiro1);
    inicializarTabuleiro(tabuleiro2);

    posicionarBarcos(tabuleiro1, SUB, Q_SUB);
    posicionarBarcos(tabuleiro1, CONTRA, Q_CONTRA);
    posicionarBarcos(tabuleiro1, TANQUE, Q_TANQUE);
    posicionarBarcos(tabuleiro1, AVIAO, Q_AVIAO);

    posicionarBarcos(tabuleiro2, SUB, Q_SUB);
    posicionarBarcos(tabuleiro2, CONTRA, Q_CONTRA);
    posicionarBarcos(tabuleiro2, TANQUE, Q_TANQUE);
    posicionarBarcos(tabuleiro2, AVIAO, Q_AVIAO);

    while (1) {
        limparTela();
        printf("======== VEZ DO JOGADOR %d ========\n", jogador);
        if (jogador == 1) {
            mostrarTabuleiro(tabuleiro2, 1);
            printf("Jogador 1 - Digite linha e coluna (ex: 2 3): ");
            while (!lerCoordenadas(&x, &y));
            if (disparar(tabuleiro2, x, y, &pontos1)) {
                if (todosNaviosDestruidos(tabuleiro2)) {
                    printf("\nJogador 1 venceu!\n");
                    break;
                }
                printf("Pressione ENTER para continuar...\n");
                getchar();
                continue;
            } else {
                jogador = 2;
            }
        } else {
            mostrarTabuleiro(tabuleiro1, 1);
            printf("Jogador 2 - Digite linha e coluna (ex: 2 3): ");
            while (!lerCoordenadas(&x, &y));
            if (disparar(tabuleiro1, x, y, &pontos2)) {
                if (todosNaviosDestruidos(tabuleiro1)) {
                    printf("\nJogador 2 venceu!\n");
                    break;
                }
                printf("Pressione ENTER para continuar...\n");
                getchar();
                continue;
            } else {
                jogador = 1;
            }
        }
        printf("Placar parcial: Jogador 1 = %d | Jogador 2 = %d\n", pontos1, pontos2);
        printf("Pressione ENTER para passar a vez...\n");
        getchar();
    }

    printf("\n==== FIM DE JOGO ====\n");
    printf("Pontuação final:\n");
    printf("Jogador 1: %d pontos\n", pontos1);
    printf("Jogador 2: %d pontos\n", pontos2);
return 0;
}